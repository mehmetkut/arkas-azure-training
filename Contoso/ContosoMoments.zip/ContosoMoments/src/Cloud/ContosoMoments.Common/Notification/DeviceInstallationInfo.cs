﻿namespace ContosoMoments.Common
{
    public class DeviceInstallationInfo
    {
        public string InstallationId { get; set; }
        public string UserId { get; set; }
    }
}
