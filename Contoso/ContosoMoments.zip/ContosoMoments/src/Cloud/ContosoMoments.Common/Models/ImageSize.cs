﻿namespace ContosoMoments.Common.Models
{
    public enum ImageSize
    {
        ExtraSmall,
        Small,
        Medium,
        Large
    }
}
