﻿using Microsoft.Azure.Mobile.Server;
using System.Collections.Generic;

namespace ContosoMoments.Common.Models
{
    public class User : EntityData
    {
    }
}
