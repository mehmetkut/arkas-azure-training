﻿namespace ContosoInsurance.Common.Data.CRM
{
    public enum ClaimDamageAssessment
    {
        Minimal = 0,
        Moderate = 1,
        Severe = 2
    }
}