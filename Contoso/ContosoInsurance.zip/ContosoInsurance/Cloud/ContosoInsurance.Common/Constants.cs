﻿namespace ContosoInsurance.Common
{
    public static class Constants
    {
        public const string CorrelationIdKey = "_ContosoInsurance_Keys_CorrelationId";
    }
}
