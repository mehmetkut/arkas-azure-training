# Contoso Insurance - Azure App Services Code Sample #

Please see the README in the root of the GitHub repository to learn more about this Visual Studio Solution and the Projects it includes.