﻿export class OtherParty{
    name: string;
    street: string;
    city: string;
    state: number;
    zip: string;
    DOB: string;
    email: string;
    policyStart: string;
    policyEnd: string;
    policyId: number;
    vehicleNumber: string;
    vehicleImageUrl: string;
    licensePlate: string;
    licensePlateImageUrl: string;
    driverLicenseNumber: string;
    driverLincenseNumberImageUrl: string;
}