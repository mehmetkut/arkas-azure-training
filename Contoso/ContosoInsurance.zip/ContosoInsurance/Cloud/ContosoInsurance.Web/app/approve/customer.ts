﻿export class Customer {
    name: string;
    street: string;
    city: string;
    state: string;
    zip: string;
    DOB: string;
    phone: string;
    email: string;
    policyStart: string;
    policyEnd: string;
    policyId: string;
    vehicleNumber: string;
    licensePlate: string;
    driverLicenseNumber: string;
}