﻿# Contoso Insurance - Azure App Services Code Sample #

This project is a partially implemented AngularJS 2.0 version of the Contoso Insurance web application.
It is not up to date with the latest database schema and APIs and does not work 100%.