﻿using Xamarin.Forms;

namespace ContosoInsurance.Views
{
    public class CustomEntry: Entry
    {
    }

    public class CustomNumberEntry : Entry
    {
    }
}
